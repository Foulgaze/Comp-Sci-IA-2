package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Export extends AppCompatActivity {
    DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        mDatabaseHelper = new DatabaseHelper(this);

        Button exportBtn = findViewById(R.id.exportBtn);
        final CheckBox reminderBox = findViewById(R.id.reminderCheck);
        final CheckBox foodBox = findViewById(R.id.foodCheck);
        final Button calendarrBtn = findViewById(R.id.calendarrBtn);


        exportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(reminderBox.isChecked() || foodBox.isChecked()){
                    toastMessage("we made i there");
                    if(foodBox.isChecked() && reminderBox.isChecked()){
                        toastMessage("Both");
                        LinkedStringList list = new LinkedStringList();
                        list.add("Food Name,Calorie Count,Date Eaten,Meal Name");
                        Cursor data = mDatabaseHelper.getData();
                        data.moveToFirst();
                        try{
                            if(data.getCount() > 0){
//
                                do{
                                    list.add(data.getString(1) + "," + data.getString(2) + "," +  data.getString(4) + "," + data.getString(5));
                                } while(data.moveToNext());
                            }
                        } finally{
                            data.close();
                        }

                        list.add("\n\n\n");
                        list.add("Date,Message,Not Completed=0 Completed=1");

                        try {
                            Cursor datatwo = mDatabaseHelper.getReminder();
                            datatwo.moveToFirst();
                            try{
                                if(datatwo.getCount() > 0){
//
                                    do{
                                        list.add(datatwo.getString(0) + "," + datatwo.getString(1) + "," + datatwo.getString(2));
                                    } while(datatwo.moveToNext());
                                }
                            } finally{
                                datatwo.close();
                            }
                            export(list);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else if(!foodBox.isChecked()){
                        toastMessage("Reminder");
                        try {
                            LinkedStringList list = new LinkedStringList();
                            list.add("Date,Message,Not Completed=0 Completed=1");
                            Cursor data = mDatabaseHelper.getReminder();
                            data.moveToFirst();
                            try{
                                if(data.getCount() > 0){
                                    do{
                                        list.add(data.getString(0) + "," + data.getString(1) + "," + data.getString(2));
                                    } while(data.moveToNext());
                                }
                            } finally{
                                data.close();
                            }
                            export(list);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else{
                        toastMessage("Food");
                        try {
                            LinkedStringList list = new LinkedStringList();
                            list.add("Food Name,Calorie Count,Date Eaten,Meal Name");
                            Cursor data = mDatabaseHelper.getData();
                            data.moveToFirst();
                            try{
                                if(data.getCount() > 0){
//
                                    do{
                                        list.add(data.getString(1) + "," + data.getString(2) + "," + data.getString(4) + "," + data.getString(5));
                                    } while(data.moveToNext());
                                }
                            } finally{
                                data.close();
                            }
                            export(list);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }


                } else{
                    toastMessage("You must check at least one of the boxes!");
                }
            }
        });

        calendarrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(Export.this, MainActivity.class);
                startActivity(changePage);
            }
        });
    }

    public void export(LinkedStringList list) throws IOException {
        FileOutputStream out = openFileOutput("data.csv", Context.MODE_PRIVATE);
        for(int i = 0 ;i < list.size(); i++){
            out.write((list.get(i)+ "\n").getBytes());
        }
        out.close();

        Context context = getApplicationContext();
        File filelocation = new File(getFilesDir(), "data.csv");
        Uri path = FileProvider.getUriForFile(context, "{applicationId}.fileprovider", filelocation);
        Intent fileIntent = new Intent(Intent.ACTION_SEND);
        fileIntent.setType("text/csv");
        fileIntent.putExtra(Intent.EXTRA_SUBJECT, "DATA");
        fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        fileIntent.putExtra(Intent.EXTRA_STREAM, path);
        startActivity(Intent.createChooser(fileIntent, "Send Mail"));
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
