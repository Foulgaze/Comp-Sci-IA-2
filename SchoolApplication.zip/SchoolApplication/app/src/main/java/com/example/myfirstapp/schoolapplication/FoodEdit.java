package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class FoodEdit extends AppCompatActivity {
    DatabaseHelper mDatabaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_edit);

        mDatabaseHelper = new DatabaseHelper(this);

        final EditText foodEdit = findViewById(R.id.foodEdit);
        final EditText calorieEdit = findViewById(R.id.calorieEdit);
        final Spinner mealSpinner = findViewById(R.id.mealSpinner);
        Button saveBtn = findViewById(R.id.saveBtn);
        Button deleteBtn = findViewById(R.id.deleteBtn);


        String[] mealArray = {"Breakfast", "Lunch", "Dinner", "Snack"};
        ArrayAdapter<String> mealAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, mealArray);
        mealAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mealSpinner.setAdapter(mealAdapter);

        foodEdit.setText(getIntent().getStringExtra("title"));
        calorieEdit.setText(getIntent().getStringExtra("calorieCount"));
        mealSpinner.setSelection(getIntent().getIntExtra("meal", 0));

        final int id = getIntent().getIntExtra("id", -1);
//        toastMessage(String.valueOf(id));


        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String foodText = foodEdit.getText().toString();
                String calorieCount = calorieEdit.getText().toString();
                if(!(foodText.length() == 0 || calorieCount.length() == 0)){
                    if(!(foodText.contains("'"))){
                        mDatabaseHelper.updateFood(id, foodText, Integer.parseInt(calorieCount), mealSpinner.getSelectedItem().toString());
//                        toastMessage(String.valueOf(id));
                        Intent changePage = new Intent(FoodEdit.this, FoodView.class);
                        changePage.putExtra("date", getIntent().getStringExtra("date"));
                        startActivity(changePage);
                    } else{
                        toastMessage("You cannot have a ' in your fields!");
                    }

                } else{
                    toastMessage("You cannot leave a field blank!");
                }

            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabaseHelper.deleteFood(id);
                Intent changePage = new Intent(FoodEdit.this, FoodView.class);
                changePage.putExtra("date",getIntent().getStringExtra("date"));
                startActivity(changePage);
            }
        });


    }
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
