package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ReminderAdd extends AppCompatActivity {
    DatabaseHelper mDatabaseHelper;
    String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_add);

        date = getIntent().getStringExtra("date");
        mDatabaseHelper = new DatabaseHelper(this);

        final EditText reminderText = findViewById(R.id.reminderText);

        Button additionBtn = findViewById(R.id.additionBtn);

        additionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp = reminderText.getText().toString();
                if(!(temp.length() == 0)){
                    mDatabaseHelper.addReminder(date, temp);
                    Intent changePage = new Intent(ReminderAdd.this, ReminderView.class);
                    changePage.putExtra("date", date);
                    startActivity(changePage);
                }else{
                    toastMessage("You can't leave any fields blank");
                }

            }
        });
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
