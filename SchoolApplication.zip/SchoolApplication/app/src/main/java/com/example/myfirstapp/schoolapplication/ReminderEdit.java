package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ReminderEdit extends AppCompatActivity {
    String date;
    DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_edit);

        mDatabaseHelper = new DatabaseHelper(this);

        date = getIntent().getStringExtra("date");
        final String message= getIntent().getStringExtra("message");

        final TextView reminderDate = findViewById(R.id.dateView);
        Button updateBtn = findViewById(R.id.updateBtn);
        Button deleteBtn = findViewById(R.id.deleteBtn);
        final EditText remindText = findViewById(R.id.remindText);

        remindText.setText(message);


        reminderDate.setText(date);


        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newMsg = remindText.getText().toString();
                if(!(newMsg.length() == 0)){
                    mDatabaseHelper.updateReminderMessage(date, message, newMsg);
                    Intent changePage = new Intent(ReminderEdit.this, ReminderView.class);
                    changePage.putExtra("date", date);
                    startActivity(changePage);
                } else{
                    toastMessage("You can't leave any fields blank!");
                }

            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabaseHelper.deleteReminder(date, message);
                Intent changePage = new Intent(ReminderEdit.this, ReminderView.class);
                changePage.putExtra("date", date);
                startActivity(changePage);
            }
        });

    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
