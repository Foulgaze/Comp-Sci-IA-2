package com.example.myfirstapp.schoolapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

public class FoodSection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_section);

//        Button addFoodBtn = findViewById(R.id.addFoodBtn);
        CalendarView calendarView = findViewById(R.id.reminderCalendarView);
        Button menuBtn = findViewById(R.id.menuBtn);




        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Intent chosenDay = new Intent(FoodSection.this, FoodView.class);
                chosenDay.putExtra("date", year + "." + (month + 1) + "." + dayOfMonth);
                startActivity(chosenDay);

            }
        });
        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(FoodSection.this, MainActivity.class);
                startActivity(changePage);
            }
        });
//        addFoodBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z"); //Format for date and time
//                String currentDateandTime = sdf.format(new Date());
//                String date = currentDateandTime.substring(0, currentDateandTime.indexOf(" "));
//                Intent foodAdd = new Intent(FoodSection.this, FoodAdd.class);
//                foodAdd.putExtra("date", date);
//                startActivity(foodAdd);
//            }
//        });
    }
}
