package com.example.myfirstapp.schoolapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.EditText;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";
    private static final String TABLE_NAME = "foodTable";
    private static final String DATABASE_NAME = "database";
    private static final String WEIGHT_TABLE = "weightTable";
    private static final String REMINDER_TABLE = "reminderTable";
    private static final String COL0 = "ID";
    private static final String COL1 = "foodName";
    private static final String COL2 = "calorieCount";
    private static final String COL3 = "timeEaten";
    private static final String COL4 = "dateEaten";
    private static final String COL5 = "mealName";
    private static final String COLTWO1 = "date";
    private static final String COLTWO2 = "weight";
    private static final String COLTHREEONE = "date";
    private static final String COLTHREETWO = "message";
    private static final String COLTHREETHREE = "completed";

    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null,1);
//        context.deleteDatabase(DATABASE_NAME);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COL1 + " TEXT, " + COL2 + " TEXT, " + COL3 + " TEXT, " + COL4 + " TEXT, " + COL5 + " TEXT)";
        String createTableTwo = "CREATE TABLE " + WEIGHT_TABLE + " (" + COLTWO1 + " TEXT, " + COLTWO2 + " TEXT)";
        String createTableThree = "CREATE TABLE " + REMINDER_TABLE + " (" + COLTHREEONE + " TEXT, " + COLTHREETWO + " TEXT, " + COLTHREETHREE + " INTEGER)";
        db.execSQL(createTable);
        db.execSQL(createTableTwo);
        db.execSQL(createTableThree);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + REMINDER_TABLE);
        onCreate(db);
    }

    /**
     * Adds all of the data to the SQLite table
     * Returns false if the insertion was not successfull
     * @param name
     * @param calories
     * @param time
     * @param date
     * @return
     */
    public boolean addData(String name, String calories, String time, String date, String mealName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL2, calories);
        contentValues.put(COL3, time);
        contentValues.put(COL4, date);
        contentValues.put(COL5, mealName);
        Log.d(TAG,"addData: Adding " + name + " to " + TABLE_NAME);
        Log.d(TAG,"addData: Adding " + calories + " to " + TABLE_NAME);
        Log.d(TAG,"addData: Adding " + time + " to " + TABLE_NAME);
        Log.d(TAG,"addData: Adding " + date + " to " + TABLE_NAME);
        Log.d(TAG,"addData: Adding " + mealName + " to " + TABLE_NAME);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return !(result == -1);
    }

    public boolean addReminder(String date, String reminder){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLTHREEONE, date);
        contentValues.put(COLTHREETWO, reminder);
        contentValues.put(COLTHREETHREE, 0);
        long result = db.insert(REMINDER_TABLE, null, contentValues);
        return !(result == -1);
    }
    public Cursor returnReminder(String date){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + REMINDER_TABLE + " WHERE " + COLTHREEONE + " = '" + date + "'";

        Cursor data = db.rawQuery(query, null);
        Log.d(TAG, "Added Cursor with Size of: " + data.getCount());
        return data;
    }

    public boolean addWeight(String date, String weight){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLTWO1, date);
        contentValues.put(COLTWO2, weight);
        String query = "SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLTWO1 + " = '" + date + "'";
        long result = 0;
        if(query.length() == 0){
            result = db.insert(WEIGHT_TABLE, null, contentValues);
        } else{
            updateWeight(date, weight);
        }
        return !(result == -1);
    }

    public Cursor dailyMeal(String mealName, String date){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL5 + " = '" + mealName + "' AND " + COL4 + " = '" + date + "'";
//        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL5 + " = '" + mealName + "'";
        Cursor data = db.rawQuery(query, null);
        Log.d(TAG, "Added cursor with Size of: " + data.getCount());
        return data;
    }

    public Cursor returnWeight(String date){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLTWO1 + " = '" + date + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor calorieCount(String date){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL4 + " = '" + date + "'";

        Cursor data = db.rawQuery(query, null);
        Log.d(TAG, "Added Cursor with Size of: " + data.getCount());
        return data;
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getWeight(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + WEIGHT_TABLE;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getReminder(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + REMINDER_TABLE;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getITemID(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COL1 + " FROM " + TABLE_NAME + " WHERE " + COL2 + " = '" + name + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public void updateFood(int id, String newName, int calories, String mealName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + TABLE_NAME + " SET " + COL1 + " = '" + newName + "', " + COL2 + " = '" + calories + "', " + COL5 + " = '" + mealName + "' WHERE " + COL0 + " = '" + id + "'";
//        String query = "UPDATE " + TABLE_NAME + " SET " + COL1 + " = '" + newName + "' WHERE " + COL0 + " = '" + id + "'";
        Log.d(TAG, "Updated Table");
        db.execSQL(query);
    }

    public void updateWeight(String date, String weight){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + WEIGHT_TABLE + " SET " + COLTWO2 + " = '" + weight + "' WHERE " + COLTWO1 + " = '" + date + "'";
        db.execSQL(query);
    }

    public void updateReminder(String date, String reminder, int status){
        Log.d(TAG, "Reminder Updated");
        SQLiteDatabase db = this.getWritableDatabase();
        status = status == 0 ? 1 : 0;
        Log.d(TAG, String.valueOf(status));
        String query = "UPDATE " + REMINDER_TABLE + " SET " + COLTHREETHREE + " = '" + status + "' WHERE " + COLTHREEONE + " = '" + date + "' AND " + COLTHREETWO + " = '" + reminder + "'";
        db.execSQL(query);
    }

    public void updateReminderMessage(String date, String oldReminder, String newReminder){
        Log.d(TAG, "Reminder Updated");
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + REMINDER_TABLE + " SET " + COLTHREETWO + " = '" + newReminder + "' WHERE " + COLTHREEONE + " = '" + date + "' AND " + COLTHREETWO + " = '" + oldReminder + "'";
        db.execSQL(query);
    }

    public void deleteFood(int id){
    SQLiteDatabase db = this.getWritableDatabase();
    String query = "DELETE FROM " + TABLE_NAME + " WHERE " + COL0 + " = '" + id + "'";
    db.execSQL(query);
    }
    public void deleteReminder(String date, String message){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + REMINDER_TABLE + " WHERE " + COLTHREEONE + " = '" + date + "'" + " AND " + COLTHREETWO + " = '" + message + "'";
        db.execSQL(query);
    }
}
