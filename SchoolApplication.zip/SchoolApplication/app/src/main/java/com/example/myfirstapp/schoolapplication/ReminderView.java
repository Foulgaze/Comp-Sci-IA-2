package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ReminderView extends AppCompatActivity {
    String date;
    DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_view);

        Button addBtn = findViewById(R.id.addBtn);
        ListView reminderView = findViewById(R.id.reminderView);
        TextView reminderDate = findViewById(R.id.reminderDate);
        Button calendarBtn = findViewById(R.id.calendarBtn);




        date = getIntent().getStringExtra("date");
        mDatabaseHelper = new DatabaseHelper(this);
        reminderDate.setText(date);
        final ArrayList<String> reminderList = returnReminders();
        final ArrayList<Integer> reminderStatus = reminderStatus();
        for(int i =0 ; i < reminderStatus.size(); i++){
            if(reminderStatus.get(i) == 0){
                reminderList.set(i, reminderList.get(i)+ " Status: Unfinished");
            } else{
                reminderList.set(i, reminderList.get(i)+ " Status: Finished");

            }
        }
        ArrayAdapter<String> reminderAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, reminderList);
        reminderView.setAdapter(reminderAdapter);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(ReminderView.this, ReminderAdd.class);
                changePage.putExtra("date", date);
                startActivity(changePage);
            }
        });

        calendarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(ReminderView.this, ReminderActivity.class);
                startActivity(changePage);
            }
        });

        reminderView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                mDatabaseHelper.updateReminder(date,reminderList.get(position).substring(0,reminderList.get(position).lastIndexOf("S")-1), reminderStatus.get(position));
                toastMessage(reminderList.get(position).substring(0,reminderList.get(position).lastIndexOf("S")-1));
                finish();
                startActivity(getIntent());
                return false;
            }
        });

        reminderView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent changePage = new Intent(ReminderView.this, ReminderEdit.class);
                changePage.putExtra("date", date);
                changePage.putExtra("message", reminderList.get(position).substring(0,reminderList.get(position).lastIndexOf("S")-1));
                startActivity(changePage);
            }
        });
    }

    public ArrayList<String> returnReminders(){
        Cursor data = mDatabaseHelper.returnReminder(date);
        ArrayList<String> returnList = new ArrayList<>();
        data.moveToFirst();
        if(data.getCount() > 0){
            returnList.add(data.getString(1));
            try {
                while (data.moveToNext()) {
                    returnList.add(data.getString(1));
                }
            } finally {
                data.close();
            }

        }
        return returnList;
    }
    public ArrayList<Integer> reminderStatus(){
        Cursor data = mDatabaseHelper.returnReminder(date);
        ArrayList<Integer> returnList = new ArrayList<>();
        data.moveToFirst();
        if(data.getCount() > 0){
            returnList.add(data.getInt(2));
            try {
                while (data.moveToNext()) {
                    returnList.add(data.getInt(2));
                }
            } finally {
                data.close();
            }

        }
        return returnList;
    }


    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
