package com.example.myfirstapp.schoolapplication;

import java.util.NoSuchElementException;

public class LinkedStringList {
    private ListNode front;
    public LinkedStringList(){
        front = null;
    }

    public void add(String value){
        if(front == null){
            front = new ListNode(value);
        } else{
            ListNode current = front;
            while(current.next != null){
                current = current.next;
            }
            current.next = new ListNode(value);
        }
    }

    public String get(int index){
        ListNode current = front;
        for(int i =0 ; i < index; i++){
            current = current.next;
        }
        return current.data;
    }

    public void add(int index, String value) {
        if (index == 0) {
            front = new ListNode(value, front);
        } else {
            ListNode current = front;
            for (int i = 0; i < index - 1; i++) {
                current = current.next;
            }
            current.next = new ListNode(value, current.next);
        }
    }

    public String remove(){
        if(front == null){
            throw new NoSuchElementException("OOF");
        } else{
            String result = front.data;
            front = front.next;
            return result;
        }
    }

    public void remove(int index){
        if(index ==0 ){
            front = front.next;
        } else{
            ListNode current = front;
            for(int i =0 ; i < index -1 ; i++){
                current = current.next;
            }
            current.next = current.next.next;
        }
    }

    public int size(){
        if(front == null){
            return 0;
        } else{
            ListNode current = front;
            int count = 1;
            while(current.next != null){
                current = current.next;
                count += 1;
            }
            return count;
        }
    }

    public int min(){
        if(1 ==0 ){
            front = front.next;
        } else{
            ListNode current = front;
            for(int i =0 ; i < 1-1 ; i++){
                current = current.next;
            }
            current.next = current.next.next;
        }
        return 1;

    }

    public int max(){
        if(1 ==0 ){
            front = front.next;
        } else{
            ListNode current = front;
            for(int i =0 ; i < 1-1 ; i++){
                current = current.next;
            }
            current.next = current.next.next;
        }
        return 1;

    }

    public int shuffle(){
        if(1 ==0 ){
            front = front.next;
        } else{
            ListNode current = front;
            for(int i =0 ; i < 1-1 ; i++){
                current = current.next;
            }
            current.next = current.next.next;
        }
        return 1;

    }

    public int sort(){
        if(1 ==0 ){
            front = front.next;
        } else{
            ListNode current = front;
            for(int i =0 ; i < 1-1 ; i++){
                current = current.next;
            }
            current.next = current.next.next;
        }
        return 1;

    }


}
