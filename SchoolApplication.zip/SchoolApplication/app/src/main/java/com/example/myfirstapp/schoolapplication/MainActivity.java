package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);



        SharedPreferences sharedPreferences = getSharedPreferences("SHARED_PREFS", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if(sharedPreferences.getInt("CALORIE_LIMIT", -1) == -1){
            editor.putInt("CALORIE_LIMIT", 2500);
            editor.apply();
        }


        ImageButton dietBtn = findViewById(R.id.dietBtn);

        ImageButton settingsBtn = findViewById(R.id.settingsBtn);

        ImageButton reminderBtn = findViewById(R.id.reminderBtn);

        ImageButton exportBtn = findViewById(R.id.exportBtn);

        dietBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent foodSection = new Intent(MainActivity.this, FoodSection.class);
                startActivity(foodSection);
            }
        });

        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent settingsSection = new Intent(MainActivity.this, SettingsSection.class);
                startActivity(settingsSection);
            }
        });

        reminderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(MainActivity.this, ReminderActivity.class);
                startActivity(changePage);
            }
        });

        exportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent changePage = new Intent(MainActivity.this, Export.class);
                startActivity(changePage);
            }
        });

    }
}
