package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class FoodView extends AppCompatActivity {
    DatabaseHelper mDatabaseHelper;
    ProgressBar calorieBar;
    TextView intCalorieText;
    String date;
    @SuppressLint("ClickableViewAccessibility")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_view);

        mDatabaseHelper = new DatabaseHelper(this);

        final ListView breakfastView = findViewById(R.id.breakfastView);
        final ListView lunchView = findViewById(R.id.lunchView);
        final ListView dinnerView = findViewById(R.id.dinnerView);
        final ListView snackView = findViewById(R.id.snackView);
        final Button calendarBtn = findViewById(R.id.calendarBtn);
        final Button addBtn = findViewById(R.id.addBtn);
        final TextView dayView = findViewById(R.id.dayView);
        final EditText weightText = findViewById(R.id.weightText);
        final Button weightBtn = findViewById(R.id.weightBtn);
        date = getIntent().getStringExtra("date");
        calorieBar = findViewById(R.id.calorieBar);
        intCalorieText =  findViewById(R.id.calorieText);


        SharedPreferences sharedPreferences = getSharedPreferences("SHARED_PREFS", MODE_PRIVATE); // Max Calorie Shared Pref
        final int calorieLimit = sharedPreferences.getInt("CALORIE_LIMIT", -1); // Max Calorie Number
        calorieBar.setMax(calorieLimit);
        dayView.setText(date);
        setCalorieBar(date, calorieLimit);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent foodAdd = new Intent(FoodView.this, FoodAdd.class);
                foodAdd.putExtra("date",date);
                startActivity(foodAdd);
            }
        });

        Cursor weightData = mDatabaseHelper.returnWeight(getIntent().getStringExtra("date"));
        if(weightData.getCount() != 0){
            weightData.moveToFirst();
            weightText.setText(weightData.getString(1));
        }

        weightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(weightText.getText().toString().length() == 0)){
                    mDatabaseHelper.addWeight(date, weightText.getText().toString());
                    toastMessage("Your Weight Has Been Set");
                } else{
                    toastMessage("You can't leave the field blank");
                }


            }
        });


        ArrayList<String> breakfastList = dailyFood("Breakfast");
        final ArrayList<String> breakfastIDs = foodID("Breakfast");
        ArrayAdapter<String> breakfastAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, breakfastList );
        breakfastView.setAdapter(breakfastAdapter);

        LayoutInflater inflater = getLayoutInflater();
        ViewGroup breakfastHeader = (ViewGroup)inflater.inflate(R.layout.breakfastheader,breakfastView,false);
        breakfastView.addHeaderView(breakfastHeader);

        breakfastView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                breakfastView.requestDisallowInterceptTouchEvent(true);
                int action = event.getActionMasked();
                switch (action) {
                    case MotionEvent.ACTION_UP:
                        breakfastView.requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });

        breakfastView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent editActivity = new Intent(FoodView.this, FoodEdit.class);
                editActivity.putExtra("date", date);
                String temp = adapterView.getItemAtPosition(i).toString();
                editActivity.putExtra("id", Integer.parseInt(breakfastIDs.get(i-1)));
                editActivity.putExtra( "title",temp.substring(0,temp.lastIndexOf('C')-1));
                editActivity.putExtra("calorieCount", temp.substring(temp.lastIndexOf('C')+10));
                editActivity.putExtra("meal", 0);
                startActivity(editActivity);
            }
        });

        ArrayList<String> lunchList = dailyFood("Lunch");
        final ArrayList<String> lunchIDs = foodID("Lunch");
        ArrayAdapter<String> lunchAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, lunchList);
        lunchView.setAdapter(lunchAdapter);

        ViewGroup lunchHeader = (ViewGroup)inflater.inflate(R.layout.lunchheader,lunchView,false);
        lunchView.addHeaderView(lunchHeader);

        lunchView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                lunchView.requestDisallowInterceptTouchEvent(true);
                int action = event.getActionMasked();
                switch (action) {
                    case MotionEvent.ACTION_UP:
                        lunchView.requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });

        lunchView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent editActivity = new Intent(FoodView.this, FoodEdit.class);
                editActivity.putExtra("date", date);
                String temp = adapterView.getItemAtPosition(i).toString();
                editActivity.putExtra("id", Integer.parseInt(lunchIDs.get(i-1)));
                editActivity.putExtra( "title",temp.substring(0,temp.lastIndexOf('C')-1));
                editActivity.putExtra("calorieCount", temp.substring(temp.lastIndexOf('C')+10));
                editActivity.putExtra("meal", 1);
                startActivity(editActivity);
            }
        });


        ArrayList<String> dinnerList = dailyFood("Dinner");
        final ArrayList<String> dinnerIDs = foodID("Dinner");

        ArrayAdapter<String> dinnerAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, dinnerList);
        dinnerView.setAdapter(dinnerAdapter);

        ViewGroup dinnerHeader = (ViewGroup)inflater.inflate(R.layout.dinnerheader,dinnerView,false);
        dinnerView.addHeaderView(dinnerHeader);

        dinnerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                dinnerView.requestDisallowInterceptTouchEvent(true);
                int action = event.getActionMasked();
                switch (action) {
                    case MotionEvent.ACTION_UP:
                        dinnerView.requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });

        dinnerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent editActivity = new Intent(FoodView.this, FoodEdit.class);
                editActivity.putExtra("date", date);
                String temp = adapterView.getItemAtPosition(i).toString();
                editActivity.putExtra("id", Integer.parseInt(dinnerIDs.get(i-1)));
                editActivity.putExtra( "title",temp.substring(0,temp.lastIndexOf('C')-1));
                editActivity.putExtra("calorieCount", temp.substring(temp.lastIndexOf('C')+10));
                editActivity.putExtra("meal", 2);
                startActivity(editActivity);
            }
        });

        ArrayList<String> snackList = dailyFood("Snack");
        final ArrayList<String> snackIDs = foodID("Snack");

        ArrayAdapter<String> snackAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, snackList);
        snackView.setAdapter(snackAdapter);
        ViewGroup snackHeader = (ViewGroup)inflater.inflate(R.layout.snackheader,snackView,false);
        snackView.addHeaderView(snackHeader);

        snackView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                snackView.requestDisallowInterceptTouchEvent(true);
                int action = event.getActionMasked();
                switch (action) {
                    case MotionEvent.ACTION_UP:
                        snackView.requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });

        snackView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent editActivity = new Intent(FoodView.this, FoodEdit.class);
                editActivity.putExtra("date", date);
                String temp = adapterView.getItemAtPosition(i).toString();
                editActivity.putExtra("id", Integer.parseInt(snackIDs.get(i-1)));
                editActivity.putExtra( "title",temp.substring(0,temp.lastIndexOf('C')-1));
                editActivity.putExtra("calorieCount", temp.substring(temp.lastIndexOf('C')+10));
                editActivity.putExtra("meal", 2);
                startActivity(editActivity);
            }
        });

        calendarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startActivity = new Intent(FoodView.this, FoodSection.class);
                startActivity.putExtra("date",date);
                startActivity(startActivity);
            }
        });


    }
    private void setCalorieBar(String date, int calorieLimt){
        Cursor data = mDatabaseHelper.calorieCount(date);
        data.moveToFirst();
        int totalCalories;
        if(data.getCount() > 0){
            totalCalories = data.getInt(2);
            try {
                while (data.moveToNext()) {
                    totalCalories += data.getInt(2);
                }
            } finally {
                data.close();
            }
//            toastMessage(String.valueOf(data.getCount()));
        } else{
            totalCalories = 0;
        }

        intCalorieText.setText(totalCalories + "/" +  calorieLimt);
        calorieBar.setProgress( totalCalories);

    }

    public ArrayList<String> dailyFood(String mealName){
//        toastMessage(String.valueOf(date.compareTo(getIntent().getStringExtra("test"))));
        ArrayList<String> returnList = new ArrayList<>();
        Cursor data = mDatabaseHelper.dailyMeal(mealName, date);
        data.moveToFirst();
        try{
            if(data.getCount() > 0){
//                toastMessage(String.valueOf(data.getCount()));
                do{
                    String tempString = data.getString(1);
                    tempString += " Calories: " + data.getString(2);
//                    tempString += " " + data.getString(0);
                    returnList.add(tempString);
                } while(data.moveToNext());
            }
        } finally{
            data.close();
        }
        return returnList;
    }
    public ArrayList<String> foodID(String mealName){
        ArrayList<String> returnList = new ArrayList<>();
        Cursor data = mDatabaseHelper.dailyMeal(mealName, date);
        data.moveToFirst();
        try{
            if(data.getCount() > 0){
//                toastMessage(String.valueOf(data.getCount()));
                do{
                    String tempString = data.getString(0);
                    returnList.add(tempString);
                } while(data.moveToNext());
            }
        } finally{
            data.close();
        }
        return returnList;
    }
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
