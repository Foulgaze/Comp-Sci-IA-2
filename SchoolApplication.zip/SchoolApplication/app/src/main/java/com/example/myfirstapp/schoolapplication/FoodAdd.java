package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This class servest to add new foods to the selected days diet
 * The calorie bar serves to represent how close you are to your daily recommended amount of calories
 */
public class FoodAdd extends AppCompatActivity {
    DatabaseHelper mDatabaseHelper;
    ProgressBar calorieBar;
    TextView intCalorieText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

//        intCalorieText =  findViewById(R.id.intCalorieText);
//        SharedPreferences sharedPreferences = getSharedPreferences("SHARED_PREFS", MODE_PRIVATE); // Max Calorie Shared Pref
//        final int calorieLimit = sharedPreferences.getInt("CALORIE_LIMIT", -1); // Max Calorie Number

//        calorieBar = findViewById(R.id.calorieBar);

        final EditText foodName = findViewById(R.id.foodEdit);
        final EditText calorieCount = findViewById(R.id.calorieCount);
        final Button submitBtn = findViewById(R.id.submitBtn);
        final Spinner mealSpinner = findViewById(R.id.mealSpinner);

//        this.deleteDatabase("foodTable");
        mDatabaseHelper = new DatabaseHelper(this);

//        calorieBar.setMax(calorieLimit); // Sets the max calories of the progress bar

        // Very temporary Setup for Calorie Bar Setting
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z"); //Format for date and time
        String currentDateandTime = sdf.format(new Date());
        String date = currentDateandTime.substring(0, currentDateandTime.indexOf(" "));
//        setCalorieBar(date, calorieLimit);
        // Very Temporary

        // Setup for the dropdown menu of meal
        String[] mealArray = {"Breakfast", "Lunch", "Dinner", "Snack"};
        ArrayAdapter<String> mealAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, mealArray);
        mealAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mealSpinner.setAdapter(mealAdapter);




        /**
         * Calls method that inserts the food data into the sqlite table
         * The inserted data is the food name, calorie amount, time of entry, date of entry, and meal name
         * It also updates the calorie progress bar with method
         */
        submitBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                String foodText = foodName.getText().toString();
                String calorieText = calorieCount.getText().toString();
                if(!(foodText.length() == 0 || calorieText.length() == 0)){
                    if(!(foodText.contains("'") || calorieText.contains("'"))){
                        String date = getIntent().getStringExtra("date");
//                        String time = String.valueOf(currentDateandTime.indexOf(currentDateandTime.indexOf("+")+1, currentDateandTime.length()));
                        AddData(foodName.getText().toString(), calorieCount.getText().toString(),"10",date, mealSpinner.getSelectedItem().toString() );
//                        setCalorieBar(date, calorieLimit); // Updates calorie bar based on foods entered on certain date
                        Intent changeTemp = new Intent(FoodAdd.this, FoodView.class);
                        changeTemp.putExtra("date", date);
                        startActivity(changeTemp);
                    } else{
                        toastMessage("You can't include ' in your titles");
                    }
                } else{
                    toastMessage("You can't leave any fields blank!");
                }

            }
        });

//        viewBtn.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Intent changeTemp = new Intent(FoodAdd.this, FoodView.class);
//                startActivity(changeTemp);
//            }
//        });



    }

    /**
     * Inserts data into sqlite table
     */
    public void AddData(String foodName, String calorieCount, String time, String date, String mealName){
        boolean insertData = mDatabaseHelper.addData(foodName, calorieCount, time, date,mealName);

        if(insertData){
            toastMessage("Data Successfully Inserted");
        } else{
            toastMessage("Something went wrong");
        }
    }

    /**
     * Sets the calorie bar when called
     * Iterates through the foods on the given dates and comes up with a total amount eaten for bar
     */
    private void setCalorieBar(String date, int calorieLimt){
        Cursor data = mDatabaseHelper.calorieCount(date);
        data.moveToFirst();
        int totalCalories;
        if(data.getCount() > 0){
            totalCalories = data.getInt(2);
            try {
                while (data.moveToNext()) {
                    totalCalories += data.getInt(2);
                }
            } finally {
                data.close();
            }
        } else{
           totalCalories = 0;
        }

        intCalorieText.setText(totalCalories + "/" +  calorieLimt);
        calorieBar.setProgress( totalCalories);

    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
