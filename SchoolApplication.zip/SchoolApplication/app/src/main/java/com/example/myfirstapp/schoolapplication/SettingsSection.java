package com.example.myfirstapp.schoolapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsSection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_section);

        Button calorieLimitBtn = findViewById(R.id.calorieLimitBtn);
        final EditText dailyCalories = findViewById(R.id.dailyCalories);
        SharedPreferences sharedPreferences = getSharedPreferences("SHARED_PREFS", MODE_PRIVATE);

        dailyCalories.setText(String.valueOf(sharedPreferences.getInt("CALORIE_LIMIT", -1)));

        calorieLimitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dailyCalories.getText().toString().equals("") || Integer.parseInt(dailyCalories.getText().toString()) < 1){
                    toastMessage("You must enter a valid value!");
                }
                SharedPreferences sharedPreferences = getSharedPreferences("SHARED_PREFS", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("CALORIE_LIMIT", Integer.parseInt(dailyCalories.getText().toString()));
                editor.apply();
                Intent mainActivity = new Intent(SettingsSection.this, MainActivity.class);
                startActivity(mainActivity);
            }
        });
    }
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
